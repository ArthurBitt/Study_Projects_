# Flask_Project1
Projeto prático de um sistema web de uma página de empregos.

<a href="https://applyjobs.onrender.com">Site</a>

* Foi usado python/flask para backend da aplicação e configuração das rotas
* Para o banco de dados foi utilizado Mysql hospedado por planetscale.
* sqlalchemy para integrar o banco de dados com o app flask.
* No frontend foram utilizados HTML, CSS e o framework css -Bootstrap
* Além disso, utilizando flask jsonify, foram geradas rotas para a coleta de dados em json
