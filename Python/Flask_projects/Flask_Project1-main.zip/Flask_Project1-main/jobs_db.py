from sqlalchemy import create_engine,text
from mysql import connector

engine = create_engine("mysql+mysqlconnector://tmsko8o574prvzcudgis:pscale_pw_NKmsR8W9MhEXXluu3Vao3GuYyuqV4VZvetNXDbv5Xci@aws"
               ".connect.psdb.cloud:3306/jobs").connect()

print("...Conectado")

#query def
def querydb():
    with engine.connect() as conn:
        result = conn.execute(text("SELECT * FROM jobs"))
        list_jobs = []
        for row in result:
            list_jobs.append(dict(row._asdict()))
        return list_jobs


def queryjobydb(id):
    with engine.connect() as conn:
        query = text("SELECT * FROM jobs WHERE id = :id")
        result = conn.execute(query.params(id=id))
        rows = result.fetchall()
        if len(rows) == 0:
            return None
        else:
            return dict(rows[0]._asdict())


def add_data(job_id, data):
    with engine.connect() as conn:
        query = text(
            "INSERT INTO applications (job_id, full_name, email, linkedin_url, education, work_experience, resume_url) "
            "VALUES (:job_id, :full_name, :email, :linkedin_url, :education, :work_experience, :resume_url)"
        ).params(
            job_id=job_id,
            full_name=data['full_name'],
            email=data['email'],
            linkedin_url=data['linkedin_url'],
            education=data['education'],
            work_experience=data['work_experience'],
            resume_url=data['resume_url']
        )
        conn.execute(query)
