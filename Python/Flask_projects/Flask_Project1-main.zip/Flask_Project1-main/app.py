from flask import Flask, render_template, jsonify,request
from jobs_db import querydb,queryjobydb,add_data
import mysql.connector

app = Flask(__name__)

@app.route("/")
def home():
    return render_template("index.html", jobs=querydb())

@app.route("/jobs/<id>")
def page_jobs(id):
    job = queryjobydb(id)
    if not job:
        return "Not Found", 404
    return render_template("job_page.html", job = job)

@app.route("/job/<id>")
def show_jsonjob(id):
    job = queryjobydb(id)
    return jsonify(job)

@app.route("/api/jobs")
def homeJson():
    jobs = querydb()
    return jsonify(jobs)

@app.route("/job/<int:id>/apply", methods=['get','POST'])
def apply_job(id):
    data = request.form
    job = queryjobydb(id)
    if not job:
        return "Not Found", 404


    linkedin_url = data.get('linkedin_url', '')


    add_data(id, data)
    return render_template('application_submitted.html', job=job, data=data)


if __name__ == "__main__":
    app.run(host="0.0.0.0", debug=True)
