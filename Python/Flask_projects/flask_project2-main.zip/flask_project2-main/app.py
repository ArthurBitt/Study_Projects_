from flask import Flask, render_template, request, redirect, session, flash, url_for


class Jogo:
    def __init__(self, jogo, categoria, console):
        self.titulo = jogo
        self.categoria = categoria
        self.console = console
            


class User:
    def __init__(self,nome,nickname,senha):
        self.nome = nome
        self.nickname = nickname
        self.senha = senha



user1 = User('Arthur', 'Bitt', 123)
user2 = User('Bittencourt', 'Add2Coffee', 321)
user3 = User('Bittencourt2', 'Bitt2', 231)

dicionario_usuarios = {user1.nickname : user1.senha,
                        user2.nickname : user2.senha,
                        user3.nickname : user3.senha}

objJogo1 = Jogo('Skyrim','RPG','PS4/XBOX ONE/NINTENDO SWITCH')
objJogo2 = Jogo('Left4Dead','FPS','PS3/XBOX 360')
objJogo3 = Jogo('Diablo 3','RPG','PS4/XBOX ONE/NINTENDO SWITCH')
jogos_lista  = [objJogo1,objJogo2,objJogo3]
    
app = Flask(__name__)
app.secret_key = '@lphaCoffee15'

@app.route('/')
def login():
    return render_template('login.html')

@app.route('/login/response', methods = ['POST'])
def autentica_login():
 # vericação de dado recebido pelo post/ esta ou nao dentro do dicionário, se estiver verifica se a senha é igual ao valor da chave 
    if request.form['usuario'] in dicionario_usuarios:
        senha = int(request.form['senha'])
        if senha == dicionario_usuarios.get(request.form['usuario']):
        
            session['usuario_logado'] = request.form['usuario']
            flash(session['usuario_logado'] + " " + "logado com sucesso!")
            return redirect(url_for('index'))
                

    else:
        flash("erro ao logar")
        return redirect(url_for('login'))
        
@app.route('/logout')
def logout():
    session['usuario_logado'] = None 
    flash("Logout realizado com sucesso!")
    return redirect(url_for('login'))

@app.route('/home')
def index():
    if "usuario_logado" not in session or session['usuario_logado'] == None:
        flash('Usuário não logado')
        return redirect('/')
    titulo = 'Jogos'
    return render_template("index.html", titulo = titulo, lista = jogos_lista)


@app.route('/cadastro')
def cadastro():
    if "usuario_logado" not in session or session['usuario_logado'] == None:
        flash('Usuário não logado')
        return redirect('/')
    titulo = 'Cadastros'
    return render_template('cadastro.html', titulo = titulo)


@app.route('/response/cadastro', methods = ['POST',])
def response():
    titulo = request.form['titulo']
    categoria = request.form['categoria']
    console = request.form['console']

    jogo4 = Jogo(titulo,categoria,console)
    jogos_lista.append(jogo4)
    return redirect(url_for('index'))


if __name__ == '__main__':
    app.run(host ='0.0.0.0', debug = True)