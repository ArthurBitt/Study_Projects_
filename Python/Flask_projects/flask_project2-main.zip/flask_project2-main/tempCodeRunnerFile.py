session['usuario_logado'] = request.form['usuario']
        flash(session['usuario_logado'] + " " + "logado com sucesso!")
        return redirect(url_for('index'))