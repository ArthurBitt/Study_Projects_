from flask import Flask, render_template, request, redirect, session, flash, url_for
from flask_sqlalchemy import SQLAlchemy



app = Flask(__name__)
app.secret_key = '@lphaCoffee15' # session secrete key

app.config['SQLALCHEMY_ECHO'] = True
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///C:\\Users\\arthu\\OneDrive\\Documentos\\Projetos\\flask_project2\\app.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False


db = SQLAlchemy(app)


with app.app_context():

    class Jogo(db.Model):
        __tablename__ = 'Jogo'
        id = db.Column(db.Integer, primary_key = True, autoincrement = True)
        jogo = db.Column(db.String)
        categoria = db.Column(db.String)
        console = db.Column(db.String)

    class User(db.Model):
        __tablename__ = 'User'
        id = db.Column(db.Integer, primary_key = True, autoincrement = True)
        nome = db.Column(db.String)
        nickname = db.Column(db.String(15))
        senha = db.Column(db.String(20))


@app.route('/')
def login():
    return render_template('login.html')

@app.route('/login/response', methods = ['POST'])
def autentica_login():
    nickname = request.form['nickname']
    senha = request.form['senha']
    tabela_nickname = User.query.filter_by(nickname = nickname).first()
    tabela_senha = User.query.filter_by(senha = senha).first()
    
 # vericação de dado recebido pelo post/ esta ou nao dentro do dicionário, se estiver verifica se a senha é igual ao valor da chave 
    if tabela_nickname != None and tabela_senha != None:
        if nickname == tabela_nickname.nickname and tabela_senha.senha == senha :
            session['usuario_logado'] = request.form['nickname']
            flash(session['usuario_logado'] + " " + "logado com sucesso!")
            return redirect(url_for('index'))
                
    else:
        flash("erro ao logar")
        return redirect(url_for('login'))
        
@app.route('/logout')
def logout():
    session['usuario_logado'] = None 
    flash("Logout realizado com sucesso!")
    return redirect(url_for('login'))

@app.route('/signin')
def sign_in():
    return render_template('signin.html', titulo = 'Sign In')

@app.route('/response/signin', methods = ['POST'])
def cadastra_user():
    nome = request.form['nome']
    nickname = request.form['nickname']
    senha = request.form['senha']
    user = User(nome = nome, nickname = nickname, senha = senha)
    db.session.add(user)
    db.session.commit()
    flash(f"Usuário {nome} foi criado com sucesso!")
    return redirect(url_for('login'))

@app.route('/home')
def index():
    if "usuario_logado" not in session or session['usuario_logado'] == None:
        flash('Usuário não logado')
        return redirect('/')
    titulo = 'Jogos'
    return render_template("index.html", titulo = titulo, lista = Jogo.query.all())

@app.route('/cadastro')
def cadastro():
    if "usuario_logado" not in session or session['usuario_logado'] == None:
        flash('Usuário não logado')
        return redirect('/')
    titulo = 'Cadastros'
    return render_template('cadastro.html', titulo = titulo)

@app.route('/response/cadastro', methods = ['POST',])
def response():
    titulo = request.form['titulo']
    categoria = request.form['categoria']
    console = request.form['console']
    jogo = Jogo(jogo = titulo,categoria = categoria,console = console)
    db.session.add(jogo)
    db.session.commit()
    return redirect(url_for('index'))

if __name__ == '__main__':
    app.run(host ='0.0.0.0', debug = True)