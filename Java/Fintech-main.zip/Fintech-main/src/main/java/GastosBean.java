public class GastosBean {
}
